/**
 * Test code for grading system and related classes
 */
public class GradingDriver {
    public static void main(String[] args) throws Exception{
        School school = new School();
        school.processTextFile("/home/huseyin/Documents/Coding/School/CS_102/Labs/Lab_06/input.txt");                        
    }
}

